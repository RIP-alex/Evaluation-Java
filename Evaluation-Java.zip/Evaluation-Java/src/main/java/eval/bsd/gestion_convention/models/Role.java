package eval.bsd.gestion_convention.models;

/**
 * Définit les rôles possibles pour un utilisateur.
 */
public enum Role {
    ADMINISTRATEUR,
    ENTREPRISE
}